import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.Box;
import javax.swing.BoxLayout;

interface ImgInterface {
    int[][][] processImg(int[][][] threeDPix, int imgRows, int imgCols);
}

class ImgMod extends Frame{
    Image rawImg;
    BufferedImage buffImage;
    int imgCols;//Numar de coloane de pixeli
    int imgRows;//Numar de randuri de pixeli
    Image modImg;//Imaginea modificata

    //Inset values for the Frame
    int inTop;
    int inLeft;

    static String theProcessingClass = "ImgMod2";

    static String theImgFile = "landscape-photo.jpg";

    MediaTracker tracker;
    Display display = new Display();
    Button replotButton = new Button("Replot");

    //Arrays ce vor contine informatiile pixelilor
    int[][][] threeDPix;
    int[][][] threeDPixMod;
    int[] oneDPix;

    //Reference to the image processing object.
    ImgInterface imageProcessingObject;

    //-------------------------------------------//

    public static void main(String[] args){
        if(args.length == 0){
            //
        }else if(args.length == 1){
            theProcessingClass = args[0];
        }else if(args.length == 2){
            theProcessingClass = args[0];
            theImgFile = args[1];
        }else{
            System.out.println("Invalid args");
            System.exit(1);
        }//end else

        System.out.println("Image file: " + theImgFile);

        //Instantiere obiect al clasei
        ImgMod obj = new ImgMod();
    }//end main
    //-------------------------------------------//

    public ImgMod(){//constructor
        //Obtine imaginea din fisierul specificat.
        //Se poate afla si in alt folder dar trebuie specificat path in linie de comanda
        rawImg = Toolkit.getDefaultToolkit().getImage(theImgFile);

        //MediaTracker pentru blocarea programului pana se incarca imaginea sau trec mai mult de 10 secunde
        tracker = new MediaTracker(this);
        tracker.addImage(rawImg,1);

        try{
            if(!tracker.waitForID(1,10000)){
                System.out.println("Load error.");
                System.exit(1);
            }//end if
        }catch(InterruptedException e){
            e.printStackTrace();
            System.exit(1);
        }//end catch

        //Verificare daca fisierul s-a incarcat corect
        if((tracker.statusAll(false) & MediaTracker.ERRORED & MediaTracker.ABORTED) != 0){
            System.out.println("Load errored or aborted");
            System.exit(1);
        }//end if

        //Obtine lungime si latime
        imgCols = rawImg.getWidth(this);
        imgRows = rawImg.getHeight(this);

        this.setTitle("Normalize Colors");
        this.setBackground(Color.WHITE);
        this.add(display);
        this.add(replotButton,BorderLayout.SOUTH);
        setVisible(true);
        //Get and store inset data for the Frame and
        // the height of the button.
        inTop = this.getInsets().top;
        inLeft = this.getInsets().left;
        int buttonHeight = replotButton.getSize().height;
        this.setSize(2*inLeft+imgCols + 1,inTop + buttonHeight + 2*imgRows + 7);

        replotButton.addActionListener(//butonul de replot
                new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        threeDPixMod = imageProcessingObject.processImg(threeDPix,imgRows,imgCols);
                        oneDPix = convertToOneDim(threeDPixMod,imgCols,imgRows);
                        modImg = createImage(new MemoryImageSource(imgCols,imgRows,oneDPix,0,imgCols));
                        display.repaint();
                    }//end actionPerformed
                }//end ActionListener
        );//end addActionListener
        //=========================================//

        //Array ce contine pixelii imaginii
        oneDPix = new int[imgCols * imgRows];
        buffImage = new BufferedImage(imgCols, imgRows, BufferedImage.TYPE_INT_ARGB);

        // Se deseneaza imaginea in bufferedImage
        Graphics g = buffImage.getGraphics();
        g.drawImage(rawImg, 0, 0, null);

        //Conversie bufferedImage in date numerice
        DataBufferInt dataBufferInt = (DataBufferInt)buffImage.getRaster().getDataBuffer();
        oneDPix = dataBufferInt.getData();

        //Conversie date de la o dimensiune la 3 dimensiuni pentru usurinta calculelor
        threeDPix = convertToThreeDim(oneDPix,imgCols,imgRows);

        //Instantiere a unui obiect a clasei imaginii de procesat
        try{
            imageProcessingObject = (ImgInterface)Class.forName(theProcessingClass).newInstance();
            Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(new ActionEvent(replotButton, ActionEvent.ACTION_PERFORMED, "Replot"));
        }catch(Exception e){
            System.out.println(e);
        }//end catch

        //Afiseara frame-ul cu cele doua imagini
        this.setVisible(true);
        //=========================================//

        //Inchidere program
        this.addWindowListener(
                new WindowAdapter(){
                    public void windowClosing(WindowEvent e){
                        System.exit(0);
                    }//end windowClosing()
                }//end WindowAdapter
        );//end addWindowListener
        //=========================================//

    }//end constructor
    //===========================================//

    class Display extends Canvas{//canvas pentru afisarea celor doua imagini
        //Suprascrierea metodei paint pentru a desena ambele imagini
        //Imaginile sunt separate de un rand de pixeli
        public void paint(Graphics g){
            //Verificare ca niciuna din imagini nu e nula
            if (tracker.statusID(1, false) == MediaTracker.COMPLETE){
                if((rawImg != null) && (modImg != null)){
                    g.drawImage(rawImg,0,0,this);
                    g.drawImage(modImg,0,imgRows + 1,this);
                }//end if
            }//end if
        }//end paint()
    }//end class myCanvas
//=============================================//

    int[][][] convertToThreeDim(int[] oneDPix,int imgCols,int imgRows){
        //array 3d pentru datele imaginii
        int[][][] data = new int[imgRows][imgCols][4];

        for(int row = 0;row < imgRows;row++){
            int[] aRow = new int[imgCols];
            for(int col = 0; col < imgCols;col++){
                int element = row * imgCols + col;
                aRow[col] = oneDPix[element];
            }//end for loop on col

            //Mutarea datelor in array
            //Operatiile pe biti sunt necesare obtinerii datelor exact pe 8 biti
            for(int col = 0;col < imgCols;col++){
                //Alpha
                data[row][col][0] = (aRow[col] >> 24) & 0xFF;
                //Rosu
                data[row][col][1] = (aRow[col] >> 16) & 0xFF;
                //Verde
                data[row][col][2] = (aRow[col] >> 8) & 0xFF;
                //Albastru
                data[row][col][3] = (aRow[col]) & 0xFF;
            }//end for loop col
        }//end for loop row
        return data;
    }//end convertToThreeDim
    //-------------------------------------------//

    //Revert conversie din 3d in 1d
    int[] convertToOneDim(int[][][] data,int imgCols,int imgRows){
        int[] oneDPix = new int[imgCols * imgRows * 4];
        for(int row = 0,cnt = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                oneDPix[cnt] = ((data[row][col][0] << 24) & 0xFF000000)
                        | ((data[row][col][1] << 16) & 0x00FF0000)
                        | ((data[row][col][2] << 8) & 0x0000FF00)
                        | ((data[row][col][3]) & 0x000000FF);
                cnt++;
            }//end for loop on col

        }//end for loop on row

        return oneDPix;
    }//end convertToOneDim
}//end ImgMod class

class ImgMod2 extends Frame implements ImgInterface{

    TextField contrastField;
    TextField brightField;
    Panel input;
    OrigHistogramPanel origHistPanel;
    NewHistogramPanel newHistPanel;
    int[] origHistogram = new int[256];
    int[] newHistogram = new int[256];


    ImgMod2(){//constructor
        //interfata vizuala unde se introduc datele de la tastatura
        Box aBox = new Box(BoxLayout.Y_AXIS);
        this.add(aBox,BorderLayout.CENTER);

        input = new Panel();

        Panel contrastPanel = new Panel();
        contrastPanel.add(new Label("Contrast"));
        contrastField = new TextField("1.0",5);
        contrastPanel.add(contrastField);
        input.add(contrastPanel);

        Panel brightnessPanel = new Panel();
        brightnessPanel.add(new Label("Luminozitate"));
        brightField = new TextField("1.0",5);
        brightnessPanel.add(brightField);
        input.add(brightnessPanel);

        input.add(new Label("Apasa Replot pentru schimbare"));

        input.setBackground(Color.WHITE);
        aBox.add(input);

        origHistPanel = new OrigHistogramPanel();
        origHistPanel.setBackground(Color.YELLOW);
        aBox.add(origHistPanel);

        newHistPanel = new NewHistogramPanel();
        newHistPanel.setBackground(Color.RED);
        aBox.add(newHistPanel);

        setTitle("Normalize Colors");
        setBounds(400,0,275,400);
        setVisible(true);
    }//end constructor
    //-------------------------------------------//

    //clase pentru desenarea de histograme pentru o mai buna vizualizare a schimbarii datelor
    class OrigHistogramPanel extends Panel{
        public void paint(Graphics g){
            final int flip = 110;
            final int shift = 5;
            g.drawLine(0 + shift,flip, 255 + shift,flip);
            for(int cnt = 0;cnt < origHistogram.length; cnt++){
                g.drawLine(cnt + shift,flip - 0, cnt + shift, flip - origHistogram[cnt]);
            }//end for loop
        }//end paint
    }//end class OrigHistogramPanel
    //-------------------------------------------//

    class NewHistogramPanel extends Panel{
        public void paint(Graphics g){
            final int flip = 110;
            final int shift = 5;
            g.drawLine(0 + shift,flip, 255 + shift,flip);
            for(int cnt = 0;cnt < newHistogram.length; cnt++){
                g.drawLine(cnt + shift,flip - 0, cnt + shift, flip - newHistogram[cnt]);
            }//end for loop
        }//end paint
    }//end class NewHistogramPanel
    //-------------------------------------------//

    public int[][][] processImg(int[][][] threeDPix, int imgRows, int imgCols){

        System.out.println("Width = " + imgCols);
        System.out.println("Height = " + imgRows);

        //Valorile preluate de la utilizatori pe care se va baza procesarea
        double contrast = Double.parseDouble(contrastField.getText());
        double brightness = Double.parseDouble(brightField.getText());

        //Copie a array-ului 3d pentru a evita posibile schimbari permanente a imaginii
        int[][][] output3D = new int[imgRows][imgCols][4];
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                output3D[row][col][0] = threeDPix[row][col][0];
                output3D[row][col][1] = threeDPix[row][col][1];
                output3D[row][col][2] = threeDPix[row][col][2];
                output3D[row][col][3] = threeDPix[row][col][3];
            }//end inner loop
        }//end outer loop


        //Medie
        int mean = getMean(output3D,imgRows,imgCols);
        System.out.println("Original mean: " + mean);
        removeMean(output3D,imgRows,imgCols,mean);

        //Medie patratica
        int rms = getRms(output3D,imgRows,imgCols);
        System.out.println("Original rms: " + rms);

        //extindere sau compresie a distributiei
        scale(output3D,imgRows,imgCols,contrast);
        System.out.println("New rms" + getRms(output3D,imgRows,imgCols));

        //Readuce media la o valoare non nula adauagand aceeasi valoare pentru fiecare culoare
        //Valoarea adaugata este produsul dintre media nou obtinua si variabila de luminozitate
        shiftMean(output3D,imgRows,imgCols, (int)(brightness*mean));
        System.out.println("New mean : " + getMean(output3D,imgRows,imgCols));

        //Limitator al valorilor culorilor intre 0 si 255 pentru siguranta
        clip(output3D,imgRows,imgCols);
        System.out.println();

        //Desenarea celor doua histograme
        origHistogram = getHistogram(threeDPix, imgRows,imgCols);
        origHistPanel.repaint();

        newHistogram = getHistogram(output3D, imgRows,imgCols);
        newHistPanel.repaint();

        return output3D;

    }//end processImg
    //-------------------------------------------//

    //Metoda ce creeaza histograma
    //Returneaza un set de date ce urmeaza sa fie desenate
    int[] getHistogram(int[][][] data3D, int imgRows,int imgCols){
        int[] hist = new int[256];
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                hist[data3D[row][col][1]]++;
                hist[data3D[row][col][2]]++;
                hist[data3D[row][col][3]]++;
            }//end inner for loop
        }//end outer for loop
        int max = 0;
        for(int cnt = 1;cnt < hist.length - 1;cnt++){
            if(hist[cnt] > max){
                max = hist[cnt];
            }//end if
        }//end for loop

        for(int cnt = 0;cnt < hist.length;cnt++){
            hist[cnt] = 100 * hist[cnt]/max;
        }//end for loop
        return hist;
    }//end getHistogram
    //-------------------------------------------//

    //Metoda ce calculeaza media culorilor
    int getMean(int[][][] data3D,int imgRows, int imgCols){

        int pixelCntr = 0;
        long accum = 0;
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                accum += data3D[row][col][1];
                accum += data3D[row][col][2];
                accum += data3D[row][col][3];
                pixelCntr += 3;
            }//end inner for loop
        }//end outer for loop

        return (int)(accum/pixelCntr);

    }//end getMean
    //-------------------------------------------//

    //Metoda ce elimina media cauzand ca noua medie sa devina 0
    void removeMean(int[][][] data3D,int imgRows, int imgCols,int mean){
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                data3D[row][col][1] -= mean;
                data3D[row][col][2] -= mean;
                data3D[row][col][3] -= mean;
            }//end inner for loop
        }//end outer for loop
    }//end removeMean
    //-------------------------------------------//

    //Metoda ce calculeaza media patratica a culorilor
    int getRms(int[][][] data3D,int imgRows, int imgCols){
        int pixelCntr = 0;
        long accum = 0;
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                accum += data3D[row][col][1] *
                        data3D[row][col][1];
                accum += data3D[row][col][2] *
                        data3D[row][col][2];
                accum += data3D[row][col][3] *
                        data3D[row][col][3];
                pixelCntr += 3;
            }//end inner for loop
        }//end outer for loop
        int meanSquare = (int)(accum/pixelCntr);
        int rms = (int)(Math.sqrt(meanSquare));
        return rms;
    }//end getRms
    //-------------------------------------------//

    //Metoda ce scaleaza datele pentru compresie/expansiune
    void scale(int[][][] data3D,int imgRows, int imgCols,double scale){
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                data3D[row][col][1] *= scale;
                data3D[row][col][2] *= scale;
                data3D[row][col][3] *= scale;
            }//end inner for loop
        }//end outer for loop
    }//end scale
    //-------------------------------------------//

    //Metoda ce schimba valoarea mediei
    void shiftMean(int[][][] data3D,int imgRows, int imgCols,int newMean){
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                data3D[row][col][1] += newMean;
                data3D[row][col][2] += newMean;
                data3D[row][col][3] += newMean;
            }//end inner for loop
        }//end outer for loop
    }//end shiftMean
    //-------------------------------------------//

    //Metoda ce limiteaza datele culorile in intervalul (0,255)
    void clip(int[][][] data3D,int imgRows, int imgCols){
        for(int row = 0;row < imgRows;row++){
            for(int col = 0;col < imgCols;col++){
                if(data3D[row][col][1] < 0)
                    data3D[row][col][1] = 0;
                if(data3D[row][col][1] > 255)
                    data3D[row][col][1] = 255;

                if(data3D[row][col][2] < 0)
                    data3D[row][col][2] = 0;
                if(data3D[row][col][2] > 255)
                    data3D[row][col][2] = 255;

                if(data3D[row][col][3] < 0)
                    data3D[row][col][3] = 0;
                if(data3D[row][col][3] > 255)
                    data3D[row][col][3] = 255;

            }//end inner for loop
        }//end outer for loop
    }//end clip
    //-------------------------------------------//

}//end class ImgMod2
